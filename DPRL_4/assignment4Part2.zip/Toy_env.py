""" 
The environment simulates the possibility of buying or selling a good. The agent can either have one unit or zero unit of that good. At each transaction with the market, the agent obtains a reward equivalent to the price of the good when selling it and the opposite when buying. In addition, a penalty of 0.5 (negative reward) is added for each transaction.
Two actions are possible for the agent:
- Action 0 corresponds to selling if the agent possesses one unit or idle if the agent possesses zero unit.
- Action 1 corresponds to buying if the agent possesses zero unit or idle if the agent already possesses one unit.
The state of the agent is made up of an history of two punctual observations:
- The price signal
- Either the agent possesses the good or not (1 or 0)
The price signal is build following the same rules for the training and the validation environment. That allows the agent to learn a strategy that exploits this successfully.

"""

import numpy as np
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA
import matplotlib.pyplot as plt
import sys
sys.path.append(r'C:\GitHub\DPRL\assignment4\deer')

from deer.base_classes import Environment

class MyEnv(Environment):
    
    def __init__(self, rng):
        """ Initialize environment."""
        # Defining our state
        self._last_ponctual_observation = [0] # At each time step, the state is one scalar
                        
        self._counter = 1
                
    def reset(self, mode):
        """ Resets the environment for a new episode.

        Parameters
        -----------
        mode : int
            -1 is for the training phase, others are for validation/test.

        Returns
        -------
        list
            Initialization of the sequence of observations used for the pseudo-state; dimension must match self.inputDimensions().
            If only the current observation is used as a (pseudo-)state, then this list is equal to self._last_ponctual_observation.
        """ 
        
        self._last_ponctual_observation = [0]

        self._counter = 1
        return [0]

    def act(self, action):
        """ Performs one time-step within the environment and updates the current observation self._last_ponctual_observation

        Parameters
        -----------
        action : int
            Integer in [0, ..., N_A] where N_A is the number of actions given by self.nActions()

        Returns
        -------
        reward: float
        """
        reward = 0

        # Defining our transitions and rewards
        
        if action == 0 and self._last_ponctual_observation[0] < 9: # action 1 not last state  => goto next state & reward 0
            self._last_ponctual_observation[0] += 1
            reward = 0
        elif action == 0 and self._last_ponctual_observation[0] == 9: # action 1 last state  => goto same state & reward 1
            self._last_ponctual_observation[0] == self._last_ponctual_observation[0]
            reward = 1
        elif action == 1 and self._last_ponctual_observation[0] > 0: # action 2 & not first state  => goto first state & reward 0
            self._last_ponctual_observation[0] == 0
            reward = 0
        elif action == 1 and self._last_ponctual_observation[0] == 0: # action 2 & first state  => goto first state & reward 0.2
            self._last_ponctual_observation[0] == 0
            reward = 0.2

        self._counter += 1
        
        return reward

    def summarizePerformance(self, test_data_set, learning_algo, **kwargs):
        """
        This function is called at every PERIOD_BTW_SUMMARY_PERFS.
        Parameters
        -----------
            test_data_set
        """
        # PLOTTING
        print ("Summary Perf")
        
        # observations = test_data_set.observations()
        list_qValues = []
        
        for i in range(10):
            list_qValues.append(learning_algo.qValues([i]))

        action1 = [item[0] for item in list_qValues]  
        action2 = [item[1] for item in list_qValues]    
        
        plt.cla()

        host = host_subplot(111)
        # plt.subplots_adjust(right=0.9, left=0.1)
    
        par1 = host.twinx()
    
        host.set_xlabel("States")
        host.set_ylabel("Q-value action 1")
        par1.set_ylabel("Q-value action 2")
    
        p1, = host.plot(action1, marker='x', c = 'r', label = 'Action1')
        p2, = par1.plot(action2, marker='o', c = 'b', label = 'Action2')
    
        host.set_ylim(-0.1, 10.00)
        par1.set_ylim(-0.1, 10.00)
    
        host.axis["left"].label.set_color(p1.get_color())
        par1.axis["right"].label.set_color(p2.get_color())
    
        plt.savefig("plot.png")
        print ("A plot of the policy obtained has been saved under the name plot.png")
    
    def inputDimensions(self):
        return [(1,)]

    def nActions(self):
        return 2  # The environment allows two different actions to be taken at each time step

    def inTerminalState(self):
        return False

    def observe(self):
        return np.array(self._last_ponctual_observation)

                


def main():
    # Can be used for debug purposes
    rng = np.random.RandomState(123456)
    myenv = MyEnv(rng)

    print (myenv.observe())
    
if __name__ == "__main__":
    main()
