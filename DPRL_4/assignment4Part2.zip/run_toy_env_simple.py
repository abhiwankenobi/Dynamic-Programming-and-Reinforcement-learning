"""Toy environment launcher. See the docs for more details about this environment.

"""

import numpy as np
import sys
sys.path.append(r'C:\GitHub\DPRL\assignment4\deer')

# CHANGES
from mpl_toolkits.axes_grid1 import host_subplot
import mpl_toolkits.axisartist as AA
import matplotlib.pyplot as plt
# /CHANGES

from deer.agent import NeuralAgent
from deer.learning_algos.q_net_keras import MyQNetwork
from Toy_env import MyEnv as Toy_env
import deer.experiment.base_controllers as bc
from deer.policies import EpsilonGreedyPolicy


rng = np.random.RandomState(123456)

# --- Instantiate environment ---
env = Toy_env(rng)

# --- Instantiate qnetwork ---
qnetwork = MyQNetwork(
    environment=env,
    random_state=rng)

# CHANGES 

qnetwork.setLearningRate(0.005)
qnetwork.setDiscountFactor(0.9)

# --- Instantiate agent ---
agent = NeuralAgent(
    env,
    qnetwork,
    random_state=rng,
    train_policy=EpsilonGreedyPolicy(qnetwork, env.nActions(), rng, 0.1)) # explicitly fixed policy here

# /CHANGES


# --- Bind controllers to the agent ---
# Before every training epoch, we want to print a summary of the agent's epsilon, discount and 
# learning rate as well as the training epoch number.
agent.attach(bc.VerboseController())

# During training epochs, we want to train the agent after every action it takes.
# Plus, we also want to display after each training episode (!= than after every training) the average bellman
# residual and the average of the V values obtained during the last episode.
agent.attach(bc.TrainerController())

# We also want to interleave a "test epoch" between each training epoch. 
agent.attach(bc.InterleavedTestEpochController(epoch_length=500))


##%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# Trying to understand 

list_qValues = []
for i in range(10):
    list_qValues.append(qnetwork.qValues([i]))

action1 = [item[0] for item in list_qValues]  
action2 = [item[1] for item in list_qValues]    

# print(action1)
# print(action2)

# action1 = observations[0][100:200]
# action2 = observations[1][100:200]

steps=np.arange(10)
# steps_long=np.arange(len(self._last_ponctual_observation)*10)/10.

#print steps,invest,prices
host = host_subplot(111)
plt.subplots_adjust(right=0.9, left=0.1)

par1 = host.twinx()

host.set_xlabel("States")
host.set_ylabel("Q-value action 1")
par1.set_ylabel("Q-value action 2")

p1, = host.plot(action1, marker='x', c = 'r', label = 'Action1')
p2, = par1.plot(action2, marker='o', c = 'b', label = 'Action2')

host.set_ylim(-0.1, 10.00)
par1.set_ylim(-0.1, 10.00)

host.axis["left"].label.set_color(p1.get_color())
par1.axis["right"].label.set_color(p2.get_color())

plt.show()
        
##%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# --- Run the experiment ---
agent.run(n_epochs=100, epoch_length=1000)


